import base64
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

token = "djEKvazAq2LrBkT0zFL_UFmTa7DSEwfTbx-eVBJMjpG3CtTGWmBsBnNMNt_I3115CLs07sHmDJb20q4LvEn9DQSLASLXMArAFPVel986vA=="
KEY_TEXT = "" # shift alt

def derive_key(key_text: str, salt: bytes) -> bytes:
    kdf = Scrypt(salt=salt, length=32, n=2**14, r=8, p=1)
    return kdf.derive(key_text.encode("utf-8"))

def decrypt(token: str, key_text: str) -> str:
    blob = base64.urlsafe_b64decode(token.encode("ascii"))
    if blob[:2] != b"v1":
        raise ValueError("Unknown format")
    salt = blob[2:18]
    nonce = blob[18:30]
    ct = blob[30:]
    key = derive_key(key_text, salt)
    return AESGCM(key).decrypt(nonce, ct, None).decode("utf-8")

if __name__ == "__main__":
    try:
        print(decrypt(token, KEY_TEXT))
    except InvalidTag:
        print("Wrong key.")
    except Exception as e:
        print(f"Error: {e}")

