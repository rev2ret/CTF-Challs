# KITE-07 Writeup

![KITE-07 challenge](<./Screenshot 2026-03-29 194027.png>)

## Challenge Info

- Category: Reverse
- Name: `KITE-07`
- Author: `h7sn`
- Flag format: `0hats{...}`

## TL;DR

- Repair code: `12-CC-FB-88-51-D7`
- Flag: `0hats{dr0n3_m1ss10n_r3c0v3r3d}`

## Files

- `drone_unlock`
- `drone_unlock-Ida.c`

The binary is a stripped 64-bit PIE ELF, but the attached decompilation file makes the logic easy to recover.

## Recon

Running `strings` on the binary immediately shows the menu flow:

- `1) View Incident Brief`
- `2) View Blackbox Snapshot`
- `3) Enter Repair Code`
- `4) Recover Mission`

The blackbox snapshot dumps 48 bytes, and the challenge text says the recovery latch expects a 6-byte calibration code. The input format is also revealed directly by the binary:

```text
FORMAT: AA-BB-CC-DD-EE-FF
```

Option `3` only parses and stores six bytes. The real work happens in option `4`.

## Parsing The Repair Code

From `drone_unlock-Ida.c`, option `3`:

1. Reads a string of length `17`
2. Verifies the format `XX-XX-XX-XX-XX-XX`
3. Converts each pair of hex characters into one byte
4. Stores the 6 parsed bytes for later use

So the unknown value is exactly 6 raw bytes.

## Recover Routine Analysis

In option `4`, the binary builds three 6-byte helper arrays plus a 6-byte permutation from constants in `.rodata`:

```c
byte_2320 = { F4, 31, CE, E1, EF, 79 }
byte_2326 = { 8C, 35, E2, F5, D4, AA }
byte_232C = { 9A, 48, 65, 09, AD, 8B }
byte_2332 = { 33, 3E, 42, 4A, 4E, 53, 69, C2 }
```

### Step 1: Build `A`

For `i = 0..5`:

```text
A[i] = rol((byte_2320[i] ^ (0x3D + 0x11*i)) & 0xFF, (i % 3) + 1)
```

That gives:

```text
A = [93, FD, 8C, 23, B9, 5F]
```

### Step 2: Build `B`

The next loop starts from `0xA7` and adds `9` each round:

```text
B[i] = A[(i + 1) % 6] ^ byte_2326[i] ^ ((0xA7 + 9*i) & 0xFF)
```

Result:

```text
B = [D6, 09, 78, 8E, 40, ED]
```

### Step 3: Build `C`

```text
C[i] = rol(B[i], 2) ^ byte_232C[i] ^ 0x5C
```

Result:

```text
C = [9D, 30, D8, 6F, F0, 60]
```

### Step 4: Build the permutation `P`

The permutation-generation loop resolves to:

```text
P = [0, 4, 3, 2, 1, 5]
```

## Recovering The 6 Bytes

The first validation loop checks:

```text
rol((code[P[i]] + A[i]) & 0xFF, i + 1) ^ B[i] == C[i]
```

This can be inverted directly:

```text
code[P[i]] = (ror(C[i] ^ B[i], i + 1) - A[i]) & 0xFF
```

Computing each byte gives:

```text
code = [12, CC, FB, 88, 51, D7]
```

So the required repair code is:

```text
12-CC-FB-88-51-D7
```

The binary also contains a second checksum-style validation, but it already matches once the bytes above are recovered.

## Decrypting The Mission

After the code passes validation, the program derives a 4-byte XOR key:

```text
k0 = code[3] ^ code[0] ^ 0xA5
k1 = code[4] ^ code[1] ^ 0x5A
k2 = code[5] ^ code[2] ^ 0x3C
k3 = (code[0] + code[1] + code[2] + code[3] + code[4] + code[5]) & 0xFF
```

With the recovered bytes:

```text
key = [3F, C7, 10, 89]
```

That key is XORed over the 64-byte buffer at `byte_233A`, revealing:

```text
0hats{dr0n3_m1ss10n_r3c0v3r3d}
```

## Verification

Running the binary with the recovered code:

```bash
printf '3\n12-CC-FB-88-51-D7\n4\n5\n' | ./drone_unlock
```

Produces:

```text
MISSION RECOVERED: 0hats{dr0n3_m1ss10n_r3c0v3r3d}
```

## Solver Script

A standalone reproducer is included as `solve.py`.

## Final Flag

```text
0hats{dr0n3_m1ss10n_r3c0v3r3d}
```
