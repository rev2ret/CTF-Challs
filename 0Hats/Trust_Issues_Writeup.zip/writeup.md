# Trust Issues - Writeup

## Challenge Image

The attached challenge screenshot showed:

- Title: `Trust Issues`
- Category/Author tag: `FRL`
- Score shown: `419`
- Prompt: `Recover the flag from the provided files.`
- Flag format: `0hats{...}`

## Files

The archive contained two files:

- `flag.enc`
- `signatures.csv`

## Step 1 - Inspect `flag.enc`

`flag.enc` was JSON and immediately gave the key-derivation hint:

```json
{
  "algo": "XOR-SHA256-CTR",
  "kdf": "SHA256(str(private_key_decimal))",
  "nonce": "0eed7e477c71f7f3",
  "ciphertext": "d39a73f6ef4591e62d7b0e88ce2b52900e59b1a92d1930673d7d1a89b399eafc1e2f680d7f61"
}
```

So the actual goal was to recover the private key as a decimal integer, hash it with SHA-256, and then decrypt the ciphertext.

## Step 2 - Inspect `signatures.csv`

The CSV had four 256-bit hex columns:

- `a`
- `b`
- `c`
- `d`

The first useful observation was that `d` always started with five zero hex digits. That means `d` was really behaving like a 236-bit value stored in a 256-bit slot.

The second useful observation was that the dataset was not completely trustworthy:

- 300 groups had the same `(a, b, d)`
- Only `c` changed inside those groups

That matched the challenge title well and suggested that some rows were decoys or malformed, so I avoided assuming the entire CSV was clean.

## Step 3 - Find the Right Signature Model

The model that worked was an ECDSA-style relation over the secp256k1 group order:

```text
n = FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
```

with the column assignment:

- `z = a`
- `r = b`
- `s = c`

and the leak:

```text
d = k >> 20
```

So the nonce was:

```text
k = (d << 20) + t
```

where the missing part `t` is only 20 bits:

```text
0 <= t < 2^20
```

Plugging that into the ECDSA equation:

```text
s * k = z + r * x mod n
```

gives:

```text
x = (s * ((d << 20) + t) - z) * r^(-1) mod n
```

For a single row, there are `2^20` possible values of `x`.

For two rows, I generated the `2^20` candidates from one row and intersected them with the `2^20` candidates from another row. Under the correct interpretation, the intersection became non-empty and yielded:

```text
x = 15614211256412886114223162288855469514996079967991908373749546854096304871787
```

There is also the equivalent `n - x` ambiguity while brute-forcing sign conventions, but the value above is the one that decrypted the flag correctly.

When checked against the full CSV, this scalar matched the valid subset of rows exactly, which confirmed the dataset was mixed with junk rows.

## Step 4 - Decrypt the Flag

From `flag.enc`, the symmetric key is:

```python
key = sha256(str(x).encode()).digest()
```

The working stream construction was:

```python
block_i = sha256(key + nonce + i.to_bytes(8, "big")).digest()
```

Then the plaintext is just:

```python
plaintext = ciphertext XOR (block_0 || block_1 || ...)
```

## Minimal Solver

```python
import hashlib
import json

x = 15614211256412886114223162288855469514996079967991908373749546854096304871787

with open("extracted/flag.enc", "r", encoding="utf-8") as f:
    obj = json.load(f)

nonce = bytes.fromhex(obj["nonce"])
ciphertext = bytes.fromhex(obj["ciphertext"])
key = hashlib.sha256(str(x).encode()).digest()

stream = b""
counter = 0
while len(stream) < len(ciphertext):
    stream += hashlib.sha256(key + nonce + counter.to_bytes(8, "big")).digest()
    counter += 1

plaintext = bytes(c ^ k for c, k in zip(ciphertext, stream[:len(ciphertext)]))
print(plaintext.decode())
```

## Flag

```text
0hats{n0nce_wa$_n0t_r@nd0m_ju$t_dr@m@}
```

## Short Summary

This challenge was solved by recognizing that:

1. `flag.enc` tells you the decryption key is derived from the decimal private key.
2. `signatures.csv` leaks the top 236 bits of the ECDSA nonce.
3. The correct mapping is `z=a`, `r=b`, `s=c`, `d=k>>20` over secp256k1.
4. Intersecting the `2^20` candidate key sets from two rows recovers the private scalar.
5. Hashing that scalar and using the SHA256-CTR-like construction decrypts the flag.
