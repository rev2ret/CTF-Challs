# Trail Writeup

This writeup documents the solution path for all three stages from the provided disk image.

The original chat screenshots were not available as local files in the workspace, so the embedded images below are recreated prompt cards for each stage.

## Stage 1

![Trail 1 prompt](images/stage1.png)

**Challenge text**

> During a system update cycle, several log entries were renamed and modified. However, one log did not remain as it originally appeared.

**Goal**

Recover the Stage 1 flag.

### Approach

The main clue was the renamed update log. On the Windows volume, both the normal `WindowsUpdate.log` and the suspicious `WindowsUpdates.log` existed side by side.

```bash
fls -o 206848 -r extracted/disk.E01 | rg "WindowsUpdates\.log|WindowsUpdate\.log"
```

Relevant hits:

```text
+ r/r 16700-128-3: WindowsUpdate.log
+ r/r 10710-128-4: WindowsUpdates.log
```

Comparing the two files immediately showed that `WindowsUpdates.log` was abnormal. The normal log had only 38 lines, while the renamed file had 391 log lines plus one extra appended line.

```bash
wc -l /tmp/trail_recover/Windows/WindowsUpdates.log /tmp/trail_recover/Windows/WindowsUpdate.log
nl -ba /tmp/trail_recover/Windows/WindowsUpdates.log | tail -n 5
```

Output:

```text
  391 /tmp/trail_recover/Windows/WindowsUpdates.log
   38 /tmp/trail_recover/Windows/WindowsUpdate.log

388  2026-03-09 18:03:41:276 ... Report CWERReporter finishing event handling. (00000000)
389  2026-03-09 18:03:41:276 ... Service *********
390  2026-03-09 18:03:41:276 ... Service **  END  **  Service: Service exit [Exit code = 0x240001]
391  2026-03-09 18:03:41:276 ... Service *************
392  VFVkb2FHUklUamRPU0ZaclRWUmtaazFUUm5wWU1teDBZMFJDZVU0eVJuVk9NekE5
```

That last line is not a normal Windows Update log entry. It is base64, and it had to be decoded multiple times:

```bash
python3 - <<'PY'
import base64
s = b'VFVkb2FHUklUamRPU0ZaclRWUmtaazFUUm5wWU1teDBZMFJDZVU0eVJuVk9NekE5'
for i in range(3):
    s = base64.b64decode(s)
    print(s.decode())
PY
```

Output:

```text
TUdoaGRITjdOSFZrTVRkZk1TRnpYMmx0Y0RCeU4yRnVOMzA9
MGhhdHN7NHVkMTdfMSFzX2ltcDByN2FuN30=
0hats{4ud17_1!s_imp0r7an7}
```

### Stage 1 Flag

```text
0hats{4ud17_1!s_imp0r7an7}
```

## Stage 2

![Trail 2 prompt](images/stage2.png)

**Challenge text**

> Some things a user interacts with leave subtle impressions behind. Even when files are closed and activity is forgotten, the system quietly keeps fragments of what was touched. Somewhere in those traces lies more than just a filename.

**Goal**

Recover the Stage 2 flag from user interaction artifacts.

### Approach

The obvious candidate was the recent file `fl4g.txt`, but that turned out to be a decoy.

```text
/tmp/trail_recover/Users/ali/Documents/welcome/fl4g.txt
```

Its content was:

```text
0hats{f4k33_flagggg}
```

The real clue was inside the user registry hive:

```text
/tmp/trail_recover/Users/ali/NTUSER.DAT
```

Specifically:

```text
Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs
```

I parsed the key with `python-registry`:

```bash
python3 - <<'PY'
from Registry import Registry
reg = Registry.Registry('/tmp/trail_recover/Users/ali/NTUSER.DAT')
key = reg.open('Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RecentDocs')

print('RecentDocs default:', key.value('(default)').value())
print('Decoded:', bytes.fromhex(key.value('(default)').value()).decode())
PY
```

Output:

```text
RecentDocs default: 4e 31 63 33 5f 46 66 49 31 21 6e 44 5f 62 69 67 4d 34 6e
Decoded: N1c3_FfI1!nD_bigM4n
```

The `.txt` recent-docs subkey also confirmed that `fl4g.txt` was only a touched file, not the real answer:

```bash
python3 - <<'PY'
from Registry import Registry
reg = Registry.Registry('/tmp/trail_recover/Users/ali/NTUSER.DAT')
key = reg.open('Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RecentDocs\\.txt')
print(key.value('0').value())
PY
```

That value references `fl4g.lnk`, which leads to the fake text file. The actual flag body was stored in the root `RecentDocs` `(default)` value, encoded as hex bytes.

### Stage 2 Flag

```text
0hats{N1c3_FfI1!nD_bigM4n}
```

## Stage 3

![Trail 3 prompt](images/stage3.png)

**Challenge text**

> What was the password for ali account?

**Goal**

Recover the password for the local user `ali`.

### Approach

The right artifacts were the Windows registry hives:

```text
/tmp/trail_recover/Windows/System32/config/SAM
/tmp/trail_recover/Windows/System32/config/SYSTEM
/tmp/trail_recover/Windows/System32/config/SECURITY
```

I extracted the local account hash with `secretsdump.py`:

```bash
secretsdump.py \
  -sam /tmp/trail_recover/Windows/System32/config/SAM \
  -system /tmp/trail_recover/Windows/System32/config/SYSTEM \
  -security /tmp/trail_recover/Windows/System32/config/SECURITY \
  LOCAL | rg '^ali:'
```

Output:

```text
ali:1000:aad3b435b51404eeaad3b435b51404ee:aefccbacf7b9da62b8a62c6b7492a3b4:::
```

The NTLM hash for `ali` was:

```text
aefccbacf7b9da62b8a62c6b7492a3b4
```

I then cracked it with the recovered potfile entry from the `rockyou` run:

```bash
printf '%s\n' 'aefccbacf7b9da62b8a62c6b7492a3b4' > /tmp/ali.hashcat
hashcat --show -m 1000 /tmp/ali.hashcat --potfile-path /tmp/hc_rock.pot
```

Output:

```text
aefccbacf7b9da62b8a62c6b7492a3b4:ali123456789
```

So the password for the `ali` account was:

```text
ali123456789
```

### Stage 3 Flag

```text
0hats{ali123456789}
```

## Final Results

```text
Stage 1: 0hats{4ud17_1!s_imp0r7an7}
Stage 2: 0hats{N1c3_FfI1!nD_bigM4n}
Stage 3: 0hats{ali123456789}
```
