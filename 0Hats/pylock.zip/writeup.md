# pylock Writeup

<img src="./Screenshot%202026-03-29%20194020.png" alt="pylock challenge screenshot" width="640">

## Challenge

The challenge gives only a compiled Python bytecode file:

`C:\Users\Mustafa\Downloads\4Hats\Reverse\pylock\challenge.pyc`

The description hints that the flag is hidden behind Python bytecode, encryption, and a bit of obfuscation.

## Step 1: Decompile the `.pyc`

An easy first step was to throw the file into an online Python decompiler such as:

`https://www.pylingual.io/`

That gave the following recovered source:

```python
"""
Pylock Challenge: Decompile and decrypt this .pyc to find the flag.
"""
_p = 2050915217
a = bytes([202, 92, 230, 227, 37, 228, 132, 22, 67, 212, 1, 131, 251, 115, 118, 157, 89, 217, 58, 226, 175, 130, 154, 72, 227, 101])
b = bytes([89, 61, 157])
c = bytes([127, 107, 88, 74, 81])

def _keygen(seed, length):
    """Derive encryption key from seed using LCG (linear congruential generator)."""
    key = []
    state = seed
    for _ in range(length):
        state = (state * 1103515245 + 12345 & 4294967295) >> 8
        key.append(state & 255)
    return bytes(key)

def d(data, seed):
    """XOR decryption with key derived from seed."""
    key = _keygen(seed, len(data))
    result = []
    for i, byte in enumerate(data):
        result.append(byte ^ key[i])
    return bytes(result)

def _checksum(data):
    """Calculate checksum: [sum_low, sum_high, length]."""
    s = sum(data)
    return bytes([s & 255, s >> 8 & 255, len(data) & 255])

def e(plaintext):
    # irreducible cflow, using cdg fallback
    """Validate format and integrity of decrypted plaintext."""
    # ***<module>.e: Failure: Compilation Error
    if not isinstance(plaintext, bytes):
        return False
    s = plaintext.decode('utf-8')
    if not s.startswith('0hats{') or not s.endswith('}'):
            return False
            expected = d(b, _p)
            actual = _checksum(plaintext)
            return expected == actual
            except UnicodeDecodeError:
                    return False

def f():
    """Main decryption and validation routine."""
    plaintext = d(a, _p)
    if e(plaintext):
        return plaintext.decode('utf-8')

if __name__ == '__main__':
    flag = f()
    if flag:
        print(f'Flag: {flag}')
    else:
        print('Decryption failed or validation error.')
```

## Step 2: Understand the logic

Even though the decompiler broke the control flow inside `e()`, the important parts are still visible:

- `_keygen()` builds a pseudo-random key stream from `_p` using an LCG.
- `d()` XORs the encrypted bytes with that key stream.
- `a` is the encrypted flag.
- `b` is an encrypted checksum.
- `_checksum()` returns `sum_low`, `sum_high`, and `length`.

The broken `e()` function is still easy to reconstruct mentally. The intended logic is effectively:

```python
def e(plaintext):
    if not isinstance(plaintext, bytes):
        return False
    try:
        s = plaintext.decode("utf-8")
        if not s.startswith("0hats{") or not s.endswith("}"):
            return False
        expected = d(b, _p)
        actual = _checksum(plaintext)
        return expected == actual
    except UnicodeDecodeError:
        return False
```

So the solve path is simple: decrypt `a` using `d(a, _p)` and verify that its checksum matches `d(b, _p)`.

## Step 3: Recover the flag

Using the decompiled routines directly:

```python
_p = 2050915217
a = bytes([202, 92, 230, 227, 37, 228, 132, 22, 67, 212, 1, 131, 251, 115, 118, 157, 89, 217, 58, 226, 175, 130, 154, 72, 227, 101])
b = bytes([89, 61, 157])

def _keygen(seed, length):
    key = []
    state = seed
    for _ in range(length):
        state = ((state * 1103515245 + 12345) & 0xFFFFFFFF) >> 8
        key.append(state & 0xFF)
    return bytes(key)

def d(data, seed):
    key = _keygen(seed, len(data))
    return bytes(byte ^ key[i] for i, byte in enumerate(data))

def checksum(data):
    s = sum(data)
    return bytes([s & 0xFF, (s >> 8) & 0xFF, len(data) & 0xFF])

plaintext = d(a, _p)
expected = d(b, _p)
actual = checksum(plaintext)

print(plaintext)
print(expected, actual)
print(plaintext.decode())
```

Output:

```text
b'0hats{decomp1l3_th1s_n0t3}'
b'\xa3\t\x1a' b'\xa3\t\x1a'
0hats{decomp1l3_th1s_n0t3}
```

The decrypted plaintext is valid UTF-8, matches the required `0hats{...}` format, and its checksum matches the expected value.

## Notes

- The first character is the digit `0`, not the letter `O`.
- The `c` byte array is not needed to recover the flag and appears to be a decoy.
- The challenge is mostly about recognizing that the decompiler output is "good enough" even when one function is partially mangled.

## Flag

`0hats{decomp1l3_th1s_n0t3}`
